package gestionScolaire.metier.model;

public enum TypeEtab {
	COLLEGE, LYCEE, PRIMAIRE, UNIVERSITE
}
