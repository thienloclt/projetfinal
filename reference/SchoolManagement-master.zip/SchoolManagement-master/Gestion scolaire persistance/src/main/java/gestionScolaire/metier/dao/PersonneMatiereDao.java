package gestionScolaire.metier.dao;

import gestionScolaire.metier.model.PersonneMatiere;

public interface PersonneMatiereDao extends Dao <PersonneMatiere , Long> {
}
