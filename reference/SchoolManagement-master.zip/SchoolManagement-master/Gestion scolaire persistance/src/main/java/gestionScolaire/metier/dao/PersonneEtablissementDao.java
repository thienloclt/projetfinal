package gestionScolaire.metier.dao;

import gestionScolaire.metier.model.PersonneEtablissement;

public interface PersonneEtablissementDao extends Dao<PersonneEtablissement, Long>{
	
}
