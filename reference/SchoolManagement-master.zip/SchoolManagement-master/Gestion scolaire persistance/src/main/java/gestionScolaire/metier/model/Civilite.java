package gestionScolaire.metier.model;

public enum Civilite {
	MME, MR
}
