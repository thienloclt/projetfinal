package gestionScolaire.metier.dao;

import gestionScolaire.metier.model.Matiere;

public interface MatiereDao extends Dao<Matiere, Long>{

}
