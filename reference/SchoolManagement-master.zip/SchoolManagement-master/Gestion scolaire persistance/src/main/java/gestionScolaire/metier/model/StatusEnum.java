package gestionScolaire.metier.model;

public enum StatusEnum {
	PROFESSEUR, DIRECTEUR, ELEVE, EXTERIEUR, CPE
}
