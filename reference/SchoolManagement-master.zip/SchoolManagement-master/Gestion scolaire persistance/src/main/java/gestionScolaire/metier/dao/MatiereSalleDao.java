package gestionScolaire.metier.dao;

import gestionScolaire.metier.model.MatiereSalle;

public interface MatiereSalleDao extends Dao<MatiereSalle , Long> {

}
