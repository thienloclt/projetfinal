package gestionScolaire.metier.model;

public enum Role {
	ADMIN, USER
}
