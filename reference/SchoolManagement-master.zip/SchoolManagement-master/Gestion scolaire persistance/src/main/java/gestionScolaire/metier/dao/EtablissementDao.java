package gestionScolaire.metier.dao;

import gestionScolaire.metier.model.Etablissement;

public interface EtablissementDao extends Dao<Etablissement, Long> {

}
