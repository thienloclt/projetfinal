package gestionScolaire.metier.dao;

import gestionScolaire.metier.model.SalleClasse;

public interface SalleClasseDao extends Dao<SalleClasse , Long> {

}
